<!DOCTYPE html>
<html lang="id">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="CMS RIMI INDONESIA">
    <meta name="author" content="Ahmad Zaelani">
    <link rel="icon" href="http://localhost/cmsroot/properties/content/favicon.png">
<title>ERROR 404</title>
<link href="../properties/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<style type="text/css">
#main {
    height: 100vh;
}
</style>
  <!-- Bootstrap core JavaScript-->
    <script src="../properties/vendor/jquery/jquery.min.js"></script>
    <script src="../properties/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="d-flex justify-content-center align-items-center" id="main">
    <h1 class="mr-3 pr-3 align-top border-right inline-block align-content-center">404</h1>
    <div class="inline-block align-middle">
    	<h2 class="font-weight-normal lead" id="desc">The page you requested was not found. <a href="javascript:history.back()">go back</a> </h2>
    </div>
</div>
</body>
</html>