
    <!-- Bootstrap core CSS -->    
    <link href="properties/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
     <link href="properties/css/kostum.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="properties/css/4-col-portfolio.css" rel="stylesheet">

  </head>