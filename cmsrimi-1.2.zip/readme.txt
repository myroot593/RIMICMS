----------------------------
Nama CMS : RIMI
Progarammer : Ahmad Zaelani
Blog : root93.co.id
----------------------------
RIMI CMS merupakan cms gratis yang dibangun menggunakan PHP, Anda dapat menggunakan, memodifikasinya sesuai kebtuhan.
Saya ucapkan terima kasih yang sebanyak - banyaknya telah menggunakan cms ini dan memberikan kritik ataupun saran
untuk keperluan pengambangan cms ini.

Dengan menggunakan RIMI CMS Anda setuju dengan syarat dan ketentuan berikut :

1. CMS RIMI merupkan cms yang dapat digunakan secara gratis
2. CMS RIMI tidak di komersilkan atau diperjual belikan tanpa seizin peimilik
3. Semua materi yang terdapat pada Cms Rimi merupakan milik root93, dapat digunakan kembali dengan seizin root93
4. Source/kode sumber yang terdapat pada cms ini dapat Anda gunakan sebebas - bebasnya
5. Jika Rimi Cms digunakan untuk keperluan, publikasi ulang, skripsi, atau TA, cantumkan root93 sebagai refrensinya

Hormat saya
ROOT93