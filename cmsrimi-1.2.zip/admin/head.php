<?php include('../databases/session.php'); ?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="RIMI CMS INDONESIA">
    <meta name="author" content="Ahmad Zaelani">
    <link rel="icon" href="http://localhost/cmsroot/properties/content/favicon.png">
    <title>CMS RIMI</title>
    