    </div>
    <!-- /.container -->

    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; CMS RIMI ROOT93 2019</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="properties/vendor/jquery/jquery.min.js"></script>
    <script src="properties/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>