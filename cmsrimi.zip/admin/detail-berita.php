<?php
// Cek URL ID apakah berisi data atau tidak
if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
    // Include config file
    require_once "../databases/koneksi.php";
    require_once "../function/admin.web.fungsi.php";
         //memanggil function detail berita
    if(detail_berita(trim($_GET["id"]))){
                /*Menampilkan satu perstau data */
                $judul_berita = $row["judul_berita"];
                $isi_berita = $row["isi_berita"];
                $penulis_berita = $row["penulis_berita"];
                $tanggal_berita = $row["tanggal_berita"];
                $gambar_berita = $row["gambar_berita"];

            }else{
                // Jika id tidak ditemukan maka alihkan ke halaman error
                header("location: error");
                exit();
    }   
    // Close connection
    mysqli_close($koneksi);
    }else{
    // Jika URL ID di Address bar kosong maka arahkan ke halaman error
    header("location: error");
    exit();
}
?>

<?php
include ('head.php');
include ('css.php');
include ('navigasi.php');
?>
      <div id="content-wrapper">
        <div class="container-fluid">
          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.php">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Detail Berita</li>
          </ol>
          <!-- Page Content -->
        <h1><?php echo $judul_berita; ?></h1>
        <hr>
        <img src="../content/<?php echo $gambar_berita; ?> " class="img-fluid">
        <?php echo htmlspecialchars_decode(htmlspecialchars_decode($isi_berita)); ?><br/>
  
    <p class="small text-lef text-muted my-5">
            <em>Ditulis pada : <?php echo $tanggal_berita; ?> oleh : <?php echo $penulis_berita; ;?> </em>
    </p>

 <?php include('footer.php');?>      