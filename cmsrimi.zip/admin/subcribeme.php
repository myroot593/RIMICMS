<?php
include ('head.php');
include ('css.php');
include ('navigasi.php');
?>
      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.html">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Subcribe Me !</li>
          </ol>

          <!-- Page Content -->
          <h3>Subcribe = Gratis</h3>
          <a href="https://www.youtube.com/channel/UCNqYyG7I_uHC7JRxi-jZdtQ?sub_confirmation=1" class="btn btn-danger btn-md"><i class="fa fa-youtube-square fa-fw fa-1x"></i>SUBCRIBE</a>
          <hr>
          <div class="embed-responsive embed-responsive-16by9">
  <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/jpGckPKSqzM?rel=0" allowfullscreen></iframe>
</div>

 <?php include('footer.php');?>      